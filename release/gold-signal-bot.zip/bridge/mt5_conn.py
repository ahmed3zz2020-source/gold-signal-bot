#!/usr/bin/env python3
"""mt5_conn.py — the ONE way the bridge talks to MT5.

Why this file exists (a real bug we hit on 2026-10-29):
  `mt5.initialize(login=..., password=..., server="")` sends the login to the
  terminal's DEFAULT server (MetaQuotes-Demo) -> "authorization on MetaQuotes-Demo
  failed (Invalid account)" and the terminal LEAVES the Exness account.
  Same with `initialize(path=...)` when it relaunches the terminal.

Rules enforced here:
  1. Attach to the RUNNING terminal FIRST, with NO credentials (keeps its session).
  2. Only log in with credentials when ALL of login+password+server are known.
  3. Never pass an empty server.
  4. After connecting, VERIFY the account (login + server). A mismatch is reported
     loudly and the caller must fail closed -> NO TRADE.

Also loads a .env file (no external dependency) so the Exness login/password never
has to be typed on the command line.
"""

import os
import sys
import time

BRIDGE_DIR = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(BRIDGE_DIR)


# ----------------------------------------------------------------- .env
def load_dotenv(start_dir=None):
    """Load KEY=VALUE pairs from the first .env found walking up from start_dir.
    Existing environment variables always win (so a shell export overrides the file).
    Returns the path of the file it loaded, or None."""
    here = start_dir or BRIDGE_DIR
    candidates = []
    env_path = os.environ.get("BRIDGE_ENV", "")
    if env_path:
        candidates.append(env_path)
    cur = here
    for _ in range(5):
        candidates.append(os.path.join(cur, ".env"))
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    for path in candidates:
        if not path or not os.path.isfile(path):
            continue
        try:
            with open(path, "r", encoding="utf-8-sig") as fh:
                for line in fh:
                    line = line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue
                    key, _, val = line.partition("=")
                    key = key.strip()
                    val = val.strip().strip('"').strip("'")
                    if key and key not in os.environ:
                        os.environ[key] = val
        except OSError:
            continue
        return path
    return None


def cfg(name, default=""):
    return (os.environ.get(name) or default).strip()


# ----------------------------------------------------------------- connect
def _norm_server(name):
    """Server names differ in case between Exness' app and the MetaQuotes list
    (Exness-MT5Real34 vs Exness-MT5ReaL34) - compare them the same way the broker
    does: letters and digits only, case insensitive."""
    return "".join(ch for ch in str(name or "").lower() if ch.isalnum())


def connect(verbose=True):
    """Connect to MT5 and return (mt5_module, info_dict).

    info_dict keys:
      ok            bool   - connected AND (no expectation OR expectation matched)
      connected     bool   - the IPC link works
      mode          str    - 'attach' | 'login' | 'none'
      login         int
      server        str
      name          str
      currency      str
      balance       float
      trade_allowed bool
      terminal_path str
      version       tuple
      expected_login int | None
      expected_server str | None
      mismatch      bool   - connected to a DIFFERENT account than configured
      problems      list[str]
    """
    # the MCP path below does NOT need the MetaTrader5 package, so a missing
    # package is not fatal - the old IPC path is only the fallback.
    mt5 = None
    try:
        import MetaTrader5 as mt5
    except ImportError:
        if verbose:
            print("   the MetaTrader5 package is not installed - the MCP server will be used")

    env_file = load_dotenv()
    login_s = cfg("MT5_LOGIN")
    password = cfg("MT5_PASSWORD")
    server = cfg("MT5_SERVER")
    path = cfg("MT5_PATH", r"C:\Program Files\MetaTrader 5\terminal64.exe")

    exp_login = int(login_s) if login_s.isdigit() else None
    exp_server = server or None

    info = {
        "ok": False, "connected": False, "mode": "none", "login": None,
        "server": "", "name": "", "currency": "", "balance": 0.0,
        "trade_allowed": False, "terminal_path": "", "version": None,
        "expected_login": exp_login, "expected_server": exp_server,
        "mismatch": False, "problems": [], "env_file": env_file or "",
    }
    if verbose:
        if env_file:
            print("   env file          :", env_file)
            print("   keys in .env      :", ", ".join(sorted(
                k for k in os.environ if k.startswith("MT5_") or k in ("RISK_PCT", "DRY_RUN"))))
            print("   password loaded   :", ("yes (%d chars)" % len(password)) if password else "NO / EMPTY")
        print("   expected account  :", exp_login or "(not set)", "|", exp_server or "(not set)")

    def _snapshot():
        acc = mt5.account_info()
        if acc is None:
            return None
        info["login"] = acc.login
        info["server"] = acc.server
        info["name"] = acc.name
        info["currency"] = getattr(acc, "currency", "")
        info["balance"] = acc.balance
        info["trade_allowed"] = bool(acc.trade_allowed)
        ti = mt5.terminal_info()
        info["terminal_path"] = ti.path if ti else ""
        info["version"] = mt5.version()
        return acc

    # ---- 0) the terminal's own MCP server first (the only way that works on the
    #         new MT5 builds - the old python IPC times out with -10005)
    try:
        import mcp_mt5
        mod, minfo = mcp_mt5.connect(verbose=verbose)
        if mod is not None:
            info.update({
                "ok": True, "connected": True, "mode": "mcp",
                "login": minfo.get("login"), "server": minfo.get("server"),
                "name": minfo.get("name"), "currency": minfo.get("currency"),
                "balance": minfo.get("balance"),
                "trade_allowed": minfo.get("trade_allowed"),
                "terminal_path": "C:\\Program Files\\MetaTrader 5",
                "version": None, "expected_login": exp_login,
                "expected_server": exp_server, "mismatch": False,
                "problems": [], "env_file": env_file or "",
                "mcp_url": minfo.get("mcp_url"),
            })
            if exp_login and info["login"] and info["login"] != exp_login:
                info["mismatch"] = True
                info["problems"].append("WRONG ACCOUNT: connected as %s, expected %s"
                                        % (info["login"], exp_login))
            if exp_server and info["server"] and _norm_server(exp_server) != _norm_server(info["server"]):
                info["mismatch"] = True
                info["problems"].append("WRONG SERVER: connected to %s, expected %s "
                                        "(the server name is case sensitive)"
                                        % (info["server"], exp_server))
            info["ok"] = info["connected"] and not info["mismatch"]
            if verbose:
                print("   connected via     : MCP")
                print("   terminal path     :", info["terminal_path"])
                for p_ in info["problems"]:
                    print("   !", p_)
            return mod, info
        else:
            info["problems"].extend(minfo.get("problems") or [])
    except Exception as exc:                                    # noqa: BLE001
        info["problems"].append("mcp adapter raised: %s" % exc)

    if mt5 is None:
        info["problems"].append("the MetaTrader5 package is missing and the MCP server did not answer")
        return None, info

    attempts = []

    # ---- 1) attach to whatever terminal is running, NO credentials.
    #         (this is the one that works when the terminal runs on another data
    #          folder - a path-based attach can time out with -10005 IPC timeout)
    for attempt in range(2):
        attempts.append(("attach-default", ""))
        try:
            ok = mt5.initialize(timeout=60_000)
        except Exception as exc:                                  # noqa: BLE001
            ok = False
            info["problems"].append("attach-default raised: %s" % exc)
        if ok and _snapshot() is not None:
            info["connected"] = True
            info["mode"] = "attach"
            break
        try:
            mt5.shutdown()
        except Exception:                                         # noqa: BLE001
            pass
        if attempt == 0:
            time.sleep(3)

    # ---- 2) attach to the terminal at the configured path
    if not info["connected"] and path and os.path.exists(path):
        attempts.append(("attach-path", path))
        try:
            ok = mt5.initialize(path=path, timeout=60_000)
        except Exception as exc:                                  # noqa: BLE001
            ok = False
            info["problems"].append("attach-path raised: %s" % exc)
        if ok and _snapshot() is not None:
            info["connected"] = True
            info["mode"] = "attach-path"

    # ---- 3) still no account -> log in explicitly (ONLY with a full triple)
    if not info["connected"]:
        if exp_login and password and exp_server:
            attempts.append(("login", exp_server))
            try:
                ok = mt5.initialize(login=exp_login, password=password,
                                    server=exp_server, timeout=60_000)
            except Exception as exc:                              # noqa: BLE001
                ok = False
                info["problems"].append("login raised: %s" % exc)
            if ok and _snapshot() is not None:
                info["connected"] = True
                info["mode"] = "login"
        else:
            info["problems"].append(
                "no account: terminal is not logged in (or MT5_SERVER is missing in .env)")

    if not info["connected"]:
        info["problems"].append("initialize failed: %s" % (mt5.last_error(),))
        if verbose:
            for kind, where in attempts:
                print("   tried %-14s %s" % (kind, where))
            for p in info["problems"]:
                print("   !", p)
        return mt5, info

    # ---- 4) VERIFY: are we on the account we think we are on?
    if exp_login and info["login"] != exp_login:
        info["mismatch"] = True
        info["problems"].append("WRONG ACCOUNT: connected as %s, expected %s"
                                % (info["login"], exp_login))
    if exp_server and info["server"] and exp_server.lower() not in info["server"].lower():
        info["mismatch"] = True
        info["problems"].append("WRONG SERVER: connected to %s, expected %s"
                                % (info["server"], exp_server))

    info["ok"] = info["connected"] and not info["mismatch"]
    if verbose:
        print("   connected via     :", info["mode"])
        print("   terminal version  :", info["version"])
        print("   terminal path     :", info["terminal_path"])
        for p in info["problems"]:
            print("   !", p)
    return mt5, info


def require_trading_account(mt5, info, verbose=True):
    """Fail-closed gate. Returns True only if we are connected to the EXPECTED
    account AND the account may trade. Never trade on a mismatch."""
    if info is None or not info.get("connected"):
        return False
    if info.get("mismatch"):
        if verbose:
            print("BLOCKED: the terminal is on a different account than the configured one.")
        return False
    if not info.get("trade_allowed"):
        if verbose:
            print("BLOCKED: 'Allow algorithmic trading' is OFF in the terminal "
                  "(or the account cannot trade).")
        return False
    if info.get("balance", 0) <= 0:
        if verbose:
            print("BLOCKED: account balance is 0 -> no position can be sized.")
        return False
    return True


if __name__ == "__main__":
    _, i = connect(verbose=True)
    print("   result            :", "OK" if i.get("ok") else "NOT READY")
    for p in i.get("problems", []):
        print("   !", p)
    sys.exit(0 if i.get("ok") else 2)

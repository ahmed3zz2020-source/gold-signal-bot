#!/usr/bin/env python3
"""test_validate.py — the bridge's own safety logic, tested WITHOUT MetaTrader.
Run: python3 bridge/test_validate.py"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from validate import validate_signal, compute_volume  # noqa: E402

PASS = FAIL = 0


def ok(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        print(f"PASS  {name}"); PASS += 1
    else:
        print(f"FAIL  {name} {extra}"); FAIL += 1


NOW = int(time.time() * 1000)


def sig(**kw):
    base = {"id": "s1", "dir": "long", "grade": "A", "entry": 4030.0, "sl": 4026.0,
            "tps": [4039.5, 4044.5, 4050.0], "ts": NOW - 5000,
            "expiresTs": NOW + 60000, "blended": 2.4}
    base.update(kw)
    return base


BASE = dict(live_price=4030.2, open_positions=[], trades_today=0, daily_r_pct=0.0,
            balance=10000.0, symbol="XAUUSDm")

# --- a good signal passes and produces a plan
passed, why, plan = validate_signal(sig(), **BASE)
ok("a clean A signal is accepted", passed and plan is not None, why)
ok("the plan is a BUY with the right numbers",
   plan and plan.action == "BUY" and plan.symbol == "XAUUSDm" and plan.sl == 4026.0,
   str(plan))

# --- the volume maths: 0.5% of 10000 = 50 USD, stop 4 points, 100 USD/point/lot
#     => 50 / (4 * 100) = 0.125 lot => rounded DOWN to the 0.01 step = 0.12
ok("the volume respects the 0.5% risk on a 4-point stop",
   abs(plan.volume - 0.12) < 1e-9, f"volume={plan.volume}")
v = compute_volume(10000, 0.5, 10, 100, 100, min_vol=0.01, step=0.01)
ok("a 10-point stop gives 0.05 lots", abs(v - 0.05) < 1e-9, f"volume={v}")
v = compute_volume(10000, 0.5, 1, 100, 100, min_vol=0.01, step=0.01)
ok("a 1-point stop gives 0.50 lots", abs(v - 0.50) < 1e-9, f"volume={v}")
v = compute_volume(10000, 0.5, 60, 100, 100, min_vol=0.01, step=0.01)
ok("a 60-point stop risks more than 0.5% -> NO lot (never round UP to the minimum)",
   v == 0.0, f"volume={v}")
# ⛔ regression (2026-10-29): the broker minimum must never push the size above the cap.
#    Exness gold has volume_min = 1.00 lot; the old code clamped 0.02 up to 1.00 = a 50x risk.
v = compute_volume(10000, 0.5, 10, 100, 100, min_vol=1.00, step=0.01)
ok("a broker minimum of 1.00 lot REFUSES the trade (never rounds up)", v == 0.0, f"volume={v}")
v = compute_volume(250000, 0.5, 10, 100, 100, min_vol=1.00, step=0.01)
ok("with enough balance the 1.00-lot minimum is used", abs(v - 1.25) < 1e-9, f"volume={v}")
passed, why, _ = validate_signal(sig(), **{**BASE, "min_vol": 1.00})
ok("a signal whose lot is below the broker minimum is refused",
   not passed and "حجم" in why, why)

# --- the refusals
passed, why, _ = validate_signal(sig(ts=NOW - 300000), **BASE)
ok("a stale signal is refused", not passed and "قديم" in why, why)
passed, why, _ = validate_signal(sig(grade="B"), **BASE)
ok("a B grade is refused", not passed, why)
passed, why, _ = validate_signal(sig(tps=[4031.0, 4032.0, 4033.0]), **BASE)
ok("a signal with RR < 2 is refused", not passed and "العائد" in why, why)
passed, why, _ = validate_signal(sig(), **{**BASE, "open_positions": [{"ticket": 1}]})
ok("a signal while a position is open is refused", not passed and "مفتوحة" in why, why)
passed, why, _ = validate_signal(sig(), **{**BASE, "trades_today": 2})
ok("the 3rd trade of the day is refused", not passed and "صفقات" in why, why)
passed, why, _ = validate_signal(sig(), **{**BASE, "daily_r_pct": 1.2})
ok("a trade that would breach the 1.5% daily cap is refused", not passed and "وقف اليوم" in why, why)
passed, why, _ = validate_signal(sig(), **{**BASE, "live_price": 4036.0})
ok("a price that drifted 6 points is refused", not passed and "اتحرك" in why, why)
passed, why, _ = validate_signal(sig(), **{**BASE, "live_price": None})
ok("no live price means no trade", not passed, why)
passed, why, _ = validate_signal(sig(expiresTs=NOW - 1000), **BASE)
ok("an expired signal is refused", not passed and "انتهت" in why, why)
passed, why, _ = validate_signal(None, **BASE)
ok("no signal means no trade", not passed, why)

# --- the short side
passed, why, plan = validate_signal(sig(dir="short", entry=4020.0, sl=4024.0,
                                    tps=[4012.0, 4005.0, 4000.0]),
                                    **{**BASE, "live_price": 4020.1})
ok("a short signal produces a SELL", passed and plan and plan.action == "SELL", why)

# --- the edge case: a 2R RR exactly at the limit is accepted
passed, why, _ = validate_signal(sig(entry=4030.0, sl=4025.0, tps=[4040.0, 4045.0, 4050.0]), **BASE)
ok("exactly 2R to the second target is accepted", passed, why)
passed, why, _ = validate_signal(sig(entry=4030.0, sl=4025.0, tps=[4034.9, 4035.5, 4040.0]), **BASE)
ok("just under 2R is refused", not passed, why)


# ═══════════════════════════════════════════════════════════════════════
#  the FIXED-LOT mode (the trader's own size) + the guards for a small account
#  Numbers from the real account: Exness Standard Cent, 3,353 USC (= $33.53),
#  1:2000 leverage, spread 0.3, 0.01 lot = 1 oz of gold.
#  On a cent account: 1 point ($1 of price) on 1.0 lot = 10,000 USC.
# ═══════════════════════════════════════════════════════════════════════
CENT = dict(live_price=4018.7, open_positions=[], trades_today=0, daily_r_pct=0.0,
            balance=3353.0, symbol="XAUUSDc", contract_size=100.0,
            point_value_per_lot=10000.0, min_vol=0.01, vol_step=0.01,
            fixed_volume=0.01, leverage=2000.0, daily_cap_pct=45.0)

p, w, pl = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                            **{**CENT})
ok("the fixed 0.01 lot is used exactly as the trader asked", p and pl and pl.volume == 0.01, w)
ok("the reported risk is the REAL one (a $4 stop on 0.01 lot = 400 USC = 11.9%)",
   p and "11.9" in w, w)

p, w, _ = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                          **{**CENT, "fixed_volume": 0})
ok("without the fixed lot the %-risk cannot reach the broker minimum -> no trade",
   not p and "حجم" in w, w)

p, w, _ = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                          **{**CENT, "fixed_volume": 0.009})
ok("a fixed size below the broker minimum is refused (never rounded up)", not p, w)
p, w, pl = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                            **{**CENT, "fixed_volume": 0.015})
ok("a fixed size is rounded DOWN to the broker step", p and pl and pl.volume == 0.01, w)

p, w, _ = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                          **{**CENT, "daily_cap_r": 3, "losses_today": 3})
ok("after 3 losing trades the day is over", not p and "وقف اليوم" in w, w)
p, w, _ = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                          **{**CENT, "daily_cap_r": 3, "losses_today": 2})
ok("the 3rd trade of the day is still allowed", p, w)

p, w, _ = validate_signal(sig(entry=4018.7, sl=4012.7, tps=[4030.7, 4038.7, 4046.7]),
                          **{**CENT, "max_risk_pct_per_trade": 15})
ok("a stop whose real risk is 18% is refused", not p and "مخاطرة" in w, w)
p, w, _ = validate_signal(sig(entry=4018.7, sl=4010.7, tps=[4034.7, 4042.7, 4050.7]),
                          **{**CENT, "max_stop_points": 6})
ok("a stop wider than the band is refused", not p and "بعيد" in w, w)
p, w, _ = validate_signal(sig(entry=4018.7, sl=4017.7, tps=[4020.7, 4021.7, 4022.7]),
                          **{**CENT, "min_stop_points": 2})
ok("a stop tighter than the band is refused", not p and "قريب" in w, w)

p, w, _ = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                          **{**CENT, "max_spread_points": 1.0, "spread_points": 1.5})
ok("a blown-out spread is refused", not p and "السبريد" in w, w)
p, w, pl = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                            **{**CENT, "spread_points": 0.3})
ok("the spread is part of the risk (a $4 stop + 0.3 spread = 4.3 points = 12.8%)",
   p and "12.8" in w, w)

p, w, _ = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                          **{**CENT, "max_margin_use_pct": 30})
ok("0.01 lot at 1:2000 uses 6% of the balance as margin -> allowed", p, w)
p, w, _ = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                          **{**CENT, "max_margin_use_pct": 30, "fixed_volume": 0.06})
ok("a size that would use 36% of the balance as margin is refused", not p and "الهامش" in w, w)

p, w, _ = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                          **{**CENT, "daily_cap_pct": 45, "daily_r_pct": 40})
ok("the daily % cap uses the real risk of the trade", not p and "وقف اليوم" in w, w)

p, w, _ = validate_signal(sig(entry=4018.7, sl=4014.7, tps=[4026.7, 4031.7, 4036.7]),
                          **{**CENT, "trades_today": 10, "max_trades_per_day": 10})
ok("the 11th trade of the day is refused", not p and "صفقات" in w, w)


# ---------------------------------------------------------------- the self-test signal
import importlib.util as _ilu
_spec = _ilu.spec_from_file_location("bridge_mod", os.path.join(os.path.dirname(os.path.abspath(__file__)), "mt5_bridge.py"))
try:
    _m = _ilu.module_from_spec(_spec); _spec.loader.exec_module(_m)
    _sig = _m.synthetic_signal(4000.0, "long")
    ok("selftest: the synthetic signal is a valid long", _sig["dir"] == "long" and _sig["entry"] == 4000.0)
    ok("selftest: its RR clears the gate (2R/3R/4R)",
       all(r >= 2 for r in _sig["rrs"][1:]), str(_sig["rrs"]))
    p2, w2, pl2 = validate_signal(_sig, **{**BASE, "live_price": 4000.0, "balance": 1000.0})
    ok("selftest: the bridge validates it and builds a plan", p2 and pl2 is not None, w2)
    ok("selftest: the plan is a BUY with the volume from the balance", pl2 and pl2.action == "BUY", str(pl2))
except Exception as _e:
    ok("selftest: the bridge module loads", False, str(_e))

print(f"\n{'ALL CHECKS PASSED' if FAIL == 0 else 'FAILURES: %d' % FAIL}  ({PASS} passed)")
sys.exit(0 if FAIL == 0 else 1)

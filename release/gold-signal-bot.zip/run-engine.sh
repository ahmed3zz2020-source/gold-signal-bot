#!/usr/bin/env bash
# keep the engine alive: if node exits, start it again in 5 seconds
cd /workspace/gold-signal-bot
export BRIDGE_TOKEN=$(cat /workspace/bridge-token.txt)
export PORT=8080
export TELEGRAM_TOKEN=$TELEGRAM_TOKEN
export TELEGRAM_CHAT_ID=$TELEGRAM_CHAT_ID
while true; do
  node src/index.js >> bot.log 2>&1
  echo "[watchdog] the engine stopped - restarting in 5s" >> bot.log
  sleep 5
done
